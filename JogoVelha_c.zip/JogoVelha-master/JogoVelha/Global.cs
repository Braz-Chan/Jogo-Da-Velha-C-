﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JogoVelha
{
    public class Global
    {      
            public static bool turn, button_disable;
        public static int player1_wins = 0, player2_wins = 0, tie = 0, rounds = 0, A = 0, B = 0, C = 0, D = 0, E = 0, F = 0, G = 0, H = 0, I = 0;
       
       
    }
   
}
